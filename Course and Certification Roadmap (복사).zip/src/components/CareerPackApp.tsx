import { useState } from "react";
import { Navigation } from "./Navigation";
import { Dashboard } from "./Dashboard";
import { DepartmentSelector, departments } from "./DepartmentSelector";
import { JobSelector } from "./JobSelector";
import { RoadmapView } from "./RoadmapView";
import { SubjectRoadmapView } from "./SubjectRoadmapView";
import { CertificationRoadmapView } from "./CertificationRoadmapView";
import { ProfileSection } from "./ProfileSection";
import { LearningProfile } from "./LearningProfile";
import { ResumeAI } from "./ResumeAI";
import { InterviewAI } from "./InterviewAI";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { GraduationCap, MapPin, BookOpen, Award, LogOut } from "lucide-react";

type PageType = 'main' | 'roadmap' | 'resume' | 'interview' | 'profile';

interface CareerPackAppProps {
  currentPage: PageType;
  onPageChange: (page: PageType) => void;
  onLogout: () => void;
}

export function CareerPackApp({ currentPage, onPageChange, onLogout }: CareerPackAppProps) {
  const [currentSection, setCurrentSection] = useState("dashboard");
  const [selectedDepartment, setSelectedDepartment] = useState("");
  const [selectedJob, setSelectedJob] = useState("");
  const [roadmapType, setRoadmapType] = useState<"subject" | "certification" | "">("");
  const [showInterviewDetail, setShowInterviewDetail] = useState(false);
  const [showResumeDetail, setShowResumeDetail] = useState(false);

  const selectedDeptData = departments.find(dept => dept.id === selectedDepartment);
  const availableJobs = selectedDeptData?.jobs || [];

  // Reset job selection when department changes
  const handleDepartmentChange = (department: string) => {
    setSelectedDepartment(department);
    setSelectedJob("");
    setRoadmapType("");
  };

  const renderRoadmapSection = () => (
    <div className="space-y-6">
      <div className="space-y-2">
        <h1 className="text-primary">취업 로드맵</h1>
        <p className="text-muted-foreground">
          학과별 직무 연계 교육과정 및 자격증 로드맵을 확인하세요
        </p>
      </div>

      <Card className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <MapPin className="w-5 h-5 text-primary" />
          <h2>학과 및 직무 선택</h2>
        </div>
        <div className="flex flex-col md:flex-row gap-4">
          <DepartmentSelector
            selectedDepartment={selectedDepartment}
            onDepartmentChange={handleDepartmentChange}
          />
          <JobSelector
            jobs={availableJobs}
            selectedJob={selectedJob}
            onJobChange={setSelectedJob}
          />
        </div>
        {selectedDepartment && !selectedJob && (
          <p className="text-muted-foreground mt-4">
            {selectedDeptData?.name}을(를) 선택하셨습니다. 이제 관심 있는 직무를 선택해주세요.
          </p>
        )}
      </Card>

      {selectedDepartment && selectedJob ? (
        <div className="space-y-6">
          {/* 로드맵 유형 선택 */}
          <Card className="p-6">
            <div className="flex items-center gap-2 mb-4">
              <h2>로드맵 유형 선택</h2>
            </div>
            <div className="flex gap-4">
              <Button
                variant={roadmapType === "subject" ? "default" : "outline"}
                onClick={() => setRoadmapType("subject")}
                className="flex items-center gap-2"
              >
                <BookOpen className="w-4 h-4" />
                교과목 로드맵
              </Button>
              <Button
                variant={roadmapType === "certification" ? "default" : "outline"}
                onClick={() => setRoadmapType("certification")}
                className="flex items-center gap-2"
              >
                <Award className="w-4 h-4" />
                자격증 로드맵
              </Button>
            </div>
          </Card>

          {/* 선택된 로드맵 표시 */}
          {roadmapType === "subject" && (
            <SubjectRoadmapView
              selectedDepartment={selectedDepartment}
              selectedJob={selectedJob}
            />
          )}
          {roadmapType === "certification" && (
            <CertificationRoadmapView
              selectedDepartment={selectedDepartment}
              selectedJob={selectedJob}
            />
          )}
          {!roadmapType && (
            <Card className="p-12">
              <div className="text-center space-y-4">
                <div className="flex justify-center gap-4">
                  <BookOpen className="w-16 h-16 text-blue-500" />
                  <Award className="w-16 h-16 text-purple-500" />
                </div>
                <div className="space-y-2">
                  <h3 className="text-lg font-medium">로드맵 유형을 선택해주세요</h3>
                  <p className="text-muted-foreground max-w-md mx-auto">
                    교과목 로드맵에서는 학년별 필수/권장 교과목을, 
                    자격증 로드맵에서는 취득 권장 자격증을 확인할 수 있습니다.
                  </p>
                </div>
              </div>
            </Card>
          )}
        </div>
      ) : (
        <Card className="p-12">
          <div className="text-center space-y-4">
            <GraduationCap className="w-16 h-16 text-muted-foreground mx-auto" />
            <div className="space-y-2">
              <h3 className="text-muted-foreground">학과 연계 교육과정 로드맵</h3>
              <p className="text-muted-foreground max-w-md mx-auto">
                원하는 학과와 직무를 선택하시면 학년별 필수 교과목과 
                취득 권장 자격증을 확인하실 수 있습니다.
              </p>
            </div>
          </div>
        </Card>
      )}
    </div>
  );

  const renderSubjectsSection = () => (
    <div className="space-y-6">
      <div className="space-y-2">
        <h1 className="text-primary flex items-center gap-2">
          <BookOpen className="w-8 h-8" />
          교과목 로드맵
        </h1>
        <p className="text-muted-foreground">
          학과·직무별 교육과정 로드맵을 확인하세요
        </p>
      </div>

      <Card className="border-2 rounded-xl p-6">
        <div className="flex items-center gap-2 mb-4">
          <MapPin className="w-5 h-5 text-primary" />
          <h2>학과 및 직무 선택</h2>
        </div>
        <div className="flex flex-col md:flex-row gap-4">
          <DepartmentSelector
            selectedDepartment={selectedDepartment}
            onDepartmentChange={handleDepartmentChange}
          />
          <JobSelector
            jobs={availableJobs}
            selectedJob={selectedJob}
            onJobChange={setSelectedJob}
          />
        </div>
        {selectedDepartment && !selectedJob && (
          <p className="text-muted-foreground mt-4">
            {selectedDeptData?.name}을(를) 선택하셨습니다. 이제 관심 있는 직무를 선택해주세요.
          </p>
        )}
      </Card>

      {selectedDepartment && selectedJob ? (
        <SubjectRoadmapView
          selectedDepartment={selectedDepartment}
          selectedJob={selectedJob}
        />
      ) : (
        <Card className="border-2 rounded-xl p-12">
          <div className="text-center space-y-4">
            <BookOpen className="w-16 h-16 text-muted-foreground mx-auto" />
            <div className="space-y-2">
              <h3 className="text-muted-foreground">학과·직무별 교육과정 로드맵</h3>
              <p className="text-muted-foreground max-w-md mx-auto">
                원하는 학과와 직무를 선택하시면 학년별 필수 교과목과 권장 교과목을 확인하실 수 있습니다.
              </p>
            </div>
          </div>
        </Card>
      )}
    </div>
  );

  const renderCertificationsSection = () => (
    <div className="space-y-6">
      <div className="space-y-2">
        <h1 className="text-primary flex items-center gap-2">
          <Award className="w-8 h-8" />
          자격증 로드맵
        </h1>
        <p className="text-muted-foreground">
          취득 권장 자격증을 확인하세요
        </p>
      </div>

      <Card className="border-2 rounded-xl p-6">
        <div className="flex items-center gap-2 mb-4">
          <MapPin className="w-5 h-5 text-primary" />
          <h2>학과 및 직무 선택</h2>
        </div>
        <div className="flex flex-col md:flex-row gap-4">
          <DepartmentSelector
            selectedDepartment={selectedDepartment}
            onDepartmentChange={handleDepartmentChange}
          />
          <JobSelector
            jobs={availableJobs}
            selectedJob={selectedJob}
            onJobChange={setSelectedJob}
          />
        </div>
        {selectedDepartment && !selectedJob && (
          <p className="text-muted-foreground mt-4">
            {selectedDeptData?.name}을(를) 선택하셨습니다. 이제 관심 있는 직무를 선택해주세요.
          </p>
        )}
      </Card>

      {selectedDepartment && selectedJob ? (
        <CertificationRoadmapView
          selectedDepartment={selectedDepartment}
          selectedJob={selectedJob}
        />
      ) : (
        <Card className="border-2 rounded-xl p-12">
          <div className="text-center space-y-4">
            <Award className="w-16 h-16 text-muted-foreground mx-auto" />
            <div className="space-y-2">
              <h3 className="text-muted-foreground">취득 권장 자격증</h3>
              <p className="text-muted-foreground max-w-md mx-auto">
                원하는 학과와 직무를 선택하시면 취득을 권장하는 자격증을 확인하실 수 있습니다.
              </p>
            </div>
          </div>
        </Card>
      )}
    </div>
  );

  const renderMainContent = () => {
    // 메인 페이지가 아닌 경우 해당 페이지 컴포넌트 렌더링
    if (currentPage === 'resume') {
      return <ResumeAI />;
    }
    if (currentPage === 'interview') {
      return <InterviewAI />;
    }
    if (currentPage === 'profile') {
      return <LearningProfile />;
    }

    // 로드맵 페이지의 경우 섹션에 따라 다르게 렌더링
    if (currentPage === 'roadmap') {
      switch (currentSection) {
        case "dashboard":
          return <Dashboard />;
        case "subjects":
          return renderSubjectsSection();
        case "certifications":
          return renderCertificationsSection();
        default:
          return <Dashboard />;
      }
    }

    // 기본값은 대시보드
    return <Dashboard />;
  };

  return (
    <div className="min-h-screen bg-[#F6F8FB]">
      <div className="flex">
        {/* Sidebar */}
        <div className="w-80 min-h-screen bg-white border-r border-gray-200 p-6">
          <Navigation 
            currentSection={currentSection}
            onSectionChange={setCurrentSection}
            currentPage={currentPage}
            onPageChange={onPageChange}
          />
          
          {/* Logout Button */}
          <div className="mt-6 pt-6 border-t border-border">
            <Button
              variant="outline"
              className="w-full justify-start"
              onClick={onLogout}
            >
              <LogOut className="w-4 h-4 mr-2" />
              로그아웃
            </Button>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1">
          <main className="p-8">
            {renderMainContent()}
          </main>
        </div>
      </div>
    </div>
  );
}