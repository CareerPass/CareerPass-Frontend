
  # Course and Certification Roadmap (복사)

  This is a code bundle for Course and Certification Roadmap (복사). The original project is available at https://www.figma.com/design/IGKRLeAeTohShGWZSKcyea/Course-and-Certification-Roadmap--%EB%B3%B5%EC%82%AC-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  